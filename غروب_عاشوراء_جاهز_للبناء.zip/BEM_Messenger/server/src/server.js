import express from 'express';
import cors from 'cors';
import { WebSocketServer } from 'ws';
import http from 'http';

const app = express();
app.use(cors());
app.use(express.json());

app.get('/health', (_, res) => res.json({ ok: true, service: 'دردشة غروب عاشوراء' }));

const server = http.createServer(app);
const wss = new WebSocketServer({ server });
const peers = new Map();

wss.on('connection', (socket, req) => {
  const url = new URL(req.url, 'http://localhost');
  const userId = url.searchParams.get('userId');
  if (!userId) return socket.close();

  peers.set(userId, socket);

  socket.on('message', raw => {
    try {
      const message = JSON.parse(raw.toString());
      const target = message.to;
      const receiver = peers.get(target);
      if (receiver && receiver.readyState === 1) {
        receiver.send(JSON.stringify({ ...message, from: userId }));
      }
    } catch (_) {}
  });

  socket.on('close', () => {
    if (peers.get(userId) === socket) peers.delete(userId);
  });
});

const port = process.env.PORT || 8080;
server.listen(port, () => console.log(`دردشة غروب عاشوراء signaling server listening on :${port}`));
