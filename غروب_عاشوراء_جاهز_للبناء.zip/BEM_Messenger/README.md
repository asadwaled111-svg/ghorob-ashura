# دردشة غروب عاشوراء — Android starter

تطبيق مراسلة ومكالمات فيديو/صوت وحالات اجتماعية، بتصميم داكن مستوحى من الصورة المرفوعة.

## المزايا الموجودة في هذا الإصدار
- تسجيل دخول برقم الهاتف العراقي بصيغة +964.
- واجهة محادثات.
- إرسال نصوص وصور وفيديوهات.
- حالات/Stories لمدة 24 ساعة.
- منشورات اجتماعية.
- شاشة مكالمة صوتية/فيديو.
- WebRTC جاهز كبنية اتصال مباشرة، مع WebSocket signaling.
- Backend Node.js بسيط للتسجيل/الإشارة.
- الصورة المرفوعة موجودة كخلفية/هوية أولية ويمكن استبدالها من داخل `assets`.

## ملاحظة مهمة
"مجاني" هنا يعني أن التطبيق لا يفرض رسوماً على المستخدم؛ الإنترنت نفسه قد يستهلك بيانات الهاتف. كما أن تشغيل TURN/Firebase/خوادم الإنتاج قد يحتاج خدمة مدفوعة حسب الاستخدام.

## التشغيل
### Flutter
1. ثبّت Flutter وAndroid Studio.
2. افتح مجلد `client`.
3. شغّل:
   `flutter pub get`
4. ضع إعدادات Firebase الخاصة بتطبيقك في `android/app/google-services.json`.
5. فعّل Phone Authentication وFirestore وStorage.
6. شغّل:
   `flutter run`

### Backend
1. ثبّت Node.js 20+.
2. ادخل `server`.
3. شغّل:
   `npm install`
4. شغّل:
   `npm start`

غيّر عنوان `SIGNALING_URL` داخل `client/lib/services/signaling_service.dart` إلى عنوان الخادم الحقيقي.

## قبل النشر
- إضافة TURN server للإتصال خلف NAT.
- قواعد Firestore/Storage آمنة.
- Rate limiting وقيود رفع الملفات.
- تشفير النقل HTTPS/WSS.
- سياسة خصوصية وشروط استخدام.
- Push notifications عبر Firebase Cloud Messaging.
- فحص رقم الهاتف وقيود إساءة الاستخدام.
