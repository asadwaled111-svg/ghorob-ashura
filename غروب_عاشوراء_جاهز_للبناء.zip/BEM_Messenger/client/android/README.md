Flutter generates the Android Gradle project with `flutter create .`. After that, add Firebase google-services.json under android/app/ and enable Phone Auth.
