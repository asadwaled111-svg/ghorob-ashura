import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final phone = TextEditingController(text: '+964');
  final code = TextEditingController();
  String? verificationId;
  bool waiting = false;

  Future<void> sendCode() async {
    setState(() => waiting = true);
    await FirebaseAuth.instance.verifyPhoneNumber(
      phoneNumber: phone.text.trim(),
      verificationCompleted: (credential) async {
        await FirebaseAuth.instance.signInWithCredential(credential);
      },
      verificationFailed: (e) {
        if (mounted) ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(e.message ?? 'تعذر إرسال الرمز')),
        );
        setState(() => waiting = false);
      },
      codeSent: (id, _) {
        setState(() {
          verificationId = id;
          waiting = false;
        });
      },
      codeAutoRetrievalTimeout: (id) => verificationId = id,
    );
  }

  Future<void> confirm() async {
    final id = verificationId;
    if (id == null) return;
    final credential = PhoneAuthProvider.credential(
      verificationId: id,
      smsCode: code.text.trim(),
    );
    await FirebaseAuth.instance.signInWithCredential(credential);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        body: Stack(
          fit: StackFit.expand,
          children: [
            Image.asset('assets/car.jpg', fit: BoxFit.cover),
            Container(color: Colors.black.withOpacity(.72)),
            SafeArea(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Text('BEM', style: TextStyle(fontSize: 46, fontWeight: FontWeight.w900)),
                    const SizedBox(height: 8),
                    const Text('مراسلة • مكالمات • حالات', style: TextStyle(color: Color(0xFFFFC400))),
                    const SizedBox(height: 35),
                    TextField(
                      controller: phone,
                      keyboardType: TextInputType.phone,
                      decoration: const InputDecoration(
                        labelText: 'رقم الهاتف العراقي',
                        hintText: '+9647XXXXXXXXX',
                        border: OutlineInputBorder(),
                      ),
                    ),
                    const SizedBox(height: 12),
                    if (verificationId != null)
                      TextField(
                        controller: code,
                        keyboardType: TextInputType.number,
                        decoration: const InputDecoration(
                          labelText: 'رمز التحقق SMS',
                          border: OutlineInputBorder(),
                        ),
                      ),
                    const SizedBox(height: 16),
                    FilledButton(
                      onPressed: waiting ? null : (verificationId == null ? sendCode : confirm),
                      child: Text(verificationId == null ? 'إرسال رمز التحقق' : 'تسجيل الدخول'),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      );
}
