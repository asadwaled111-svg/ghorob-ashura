import 'package:flutter/material.dart';
import 'chat_screen.dart';
import 'login_screen.dart';
import 'stories_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int index = 0;

  @override
  Widget build(BuildContext context) {
    final pages = [
      const _ChatsTab(),
      const StoriesScreen(),
      const _CallsTab(),
      const _ProfileTab(),
    ];

    return Scaffold(
      appBar: AppBar(
        title: const Text('BEM'),
        centerTitle: false,
        actions: [
          IconButton(
            icon: const Icon(Icons.search),
            onPressed: () {},
          ),
          IconButton(
            icon: const Icon(Icons.camera_alt_outlined),
            onPressed: () {},
          ),
        ],
      ),
      body: pages[index],
      floatingActionButton: index == 0
          ? FloatingActionButton(
              backgroundColor: const Color(0xFFFFC400),
              foregroundColor: Colors.black,
              onPressed: () {},
              child: const Icon(Icons.chat),
            )
          : null,
      bottomNavigationBar: NavigationBar(
        selectedIndex: index,
        onDestinationSelected: (v) => setState(() => index = v),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.chat_bubble_outline), selectedIcon: Icon(Icons.chat_bubble), label: 'الدردشة'),
          NavigationDestination(icon: Icon(Icons.auto_stories_outlined), selectedIcon: Icon(Icons.auto_stories), label: 'الحالات'),
          NavigationDestination(icon: Icon(Icons.call_outlined), selectedIcon: Icon(Icons.call), label: 'المكالمات'),
          NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'حسابي'),
        ],
      ),
    );
  }
}

class _ChatsTab extends StatelessWidget {
  const _ChatsTab();

  @override
  Widget build(BuildContext context) {
    final chats = ['أحمد', 'علي', 'محمد', 'BEM Support'];
    return ListView.separated(
      padding: const EdgeInsets.all(12),
      itemCount: chats.length,
      separatorBuilder: (_, __) => const Divider(height: 1),
      itemBuilder: (_, i) => ListTile(
        leading: CircleAvatar(
          backgroundColor: const Color(0xFF222222),
          child: Text(chats[i][0]),
        ),
        title: Text(chats[i]),
        subtitle: const Text('اضغط لفتح المحادثة'),
        trailing: const Text('11:49'),
        onTap: () => Navigator.push(
          context,
          MaterialPageRoute(builder: (_) => ChatScreen(name: chats[i])),
        ),
      ),
    );
  }
}

class _CallsTab extends StatelessWidget {
  const _CallsTab();
  @override
  Widget build(BuildContext context) => const Center(
        child: Text('سجل المكالمات الصوتية ومكالمات الفيديو'),
      );
}

class _ProfileTab extends StatelessWidget {
  const _ProfileTab();
  @override
  Widget build(BuildContext context) => ListView(
        padding: const EdgeInsets.all(20),
        children: const [
          CircleAvatar(radius: 42, child: Icon(Icons.person, size: 42)),
          SizedBox(height: 16),
          Center(child: Text('حساب BEM', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold))),
          SizedBox(height: 24),
          ListTile(leading: Icon(Icons.phone), title: Text('رقم الهاتف العراقي'), subtitle: Text('+964 ...')),
          ListTile(leading: Icon(Icons.lock_outline), title: Text('الخصوصية والأمان')),
          ListTile(leading: Icon(Icons.notifications_none), title: Text('الإشعارات')),
        ],
      );
}
