import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

class StoriesScreen extends StatefulWidget {
  const StoriesScreen({super.key});
  @override
  State<StoriesScreen> createState() => _StoriesScreenState();
}

class _StoriesScreenState extends State<StoriesScreen> {
  final picker = ImagePicker();

  Future<void> addStory() async {
    final file = await picker.pickMedia();
    if (file == null) return;
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('تم اختيار ${file.name} — ارفع الملف إلى Firebase Storage ثم أنشئ Story')),
      );
    }
  }

  @override
  Widget build(BuildContext context) => ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            clipBehavior: Clip.antiAlias,
            child: InkWell(
              onTap: addStory,
              child: SizedBox(
                height: 170,
                child: Stack(
                  fit: StackFit.expand,
                  children: [
                    Image.asset('assets/car.jpg', fit: BoxFit.cover),
                    Container(color: Colors.black45),
                    const Center(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.add_circle_outline, size: 44, color: Color(0xFFFFC400)),
                          SizedBox(height: 8),
                          Text('أضف حالة أو فيديو'),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          const SizedBox(height: 18),
          const Text('الحالات والمنشورات', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          const SizedBox(height: 10),
          for (final name in ['أحمد', 'علي', 'محمد'])
            ListTile(
              leading: const CircleAvatar(child: Icon(Icons.person)),
              title: Text(name),
              subtitle: const Text('حالة متاحة'),
              trailing: const Icon(Icons.chevron_left),
            ),
        ],
      );
}
