import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

class ChatScreen extends StatefulWidget {
  final String name;
  const ChatScreen({super.key, required this.name});

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final msg = TextEditingController();
  final messages = <String>[];

  void send() {
    final text = msg.text.trim();
    if (text.isEmpty) return;
    setState(() => messages.add(text));
    msg.clear();
  }

  Future<void> pickMedia() async {
    await ImagePicker().pickMedia();
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('تم اختيار الوسائط — اربط Storage لرفعها')),
      );
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(
          title: Text(widget.name),
          actions: [
            IconButton(icon: const Icon(Icons.videocam_outlined), onPressed: () {}),
            IconButton(icon: const Icon(Icons.call_outlined), onPressed: () {}),
          ],
        ),
        body: Column(
          children: [
            Expanded(
              child: ListView.builder(
                reverse: true,
                padding: const EdgeInsets.all(12),
                itemCount: messages.length,
                itemBuilder: (_, i) => Align(
                  alignment: Alignment.centerRight,
                  child: Container(
                    margin: const EdgeInsets.only(bottom: 8),
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                    decoration: BoxDecoration(
                      color: const Color(0xFFFFC400),
                      borderRadius: BorderRadius.circular(18),
                    ),
                    child: Text(messages[messages.length - 1 - i], style: const TextStyle(color: Colors.black)),
                  ),
                ),
              ),
            ),
            SafeArea(
              child: Row(
                children: [
                  IconButton(onPressed: pickMedia, icon: const Icon(Icons.attach_file)),
                  Expanded(
                    child: TextField(
                      controller: msg,
                      decoration: const InputDecoration(hintText: 'اكتب رسالة...'),
                      onSubmitted: (_) => send(),
                    ),
                  ),
                  IconButton(
                    onPressed: send,
                    icon: const Icon(Icons.send),
                    color: const Color(0xFFFFC400),
                  ),
                ],
              ),
            ),
          ],
        ),
      );
}
