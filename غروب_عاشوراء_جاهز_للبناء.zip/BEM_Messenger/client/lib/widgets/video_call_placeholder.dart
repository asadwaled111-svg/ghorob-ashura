import 'package:flutter/material.dart';

class VideoCallPlaceholder extends StatelessWidget {
  const VideoCallPlaceholder({super.key});

  @override
  Widget build(BuildContext context) => Scaffold(
        backgroundColor: Colors.black,
        body: SafeArea(
          child: Stack(
            children: [
              const Center(
                child: Icon(Icons.videocam, size: 90, color: Colors.white24),
              ),
              Align(
                alignment: Alignment.bottomCenter,
                child: Padding(
                  padding: const EdgeInsets.all(28),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      FloatingActionButton(
                        onPressed: () {},
                        child: const Icon(Icons.mic),
                      ),
                      FloatingActionButton(
                        backgroundColor: Colors.red,
                        onPressed: () => Navigator.pop(context),
                        child: const Icon(Icons.call_end),
                      ),
                      FloatingActionButton(
                        onPressed: () {},
                        child: const Icon(Icons.videocam),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      );
}
