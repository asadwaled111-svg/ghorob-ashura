import 'dart:convert';
import 'package:web_socket_channel/web_socket_channel.dart';

class SignalingService {
  // Replace with your HTTPS/WSS production endpoint.
  static const signalingUrl = 'ws://10.0.2.2:8080';

  late final WebSocketChannel channel;

  void connect(String userId) {
    channel = WebSocketChannel.connect(Uri.parse('$signalingUrl?userId=$userId'));
  }

  void send(Map<String, dynamic> data) {
    channel.sink.add(jsonEncode(data));
  }

  Stream<Map<String, dynamic>> get messages =>
      channel.stream.map((e) => Map<String, dynamic>.from(jsonDecode(e as String)));

  Future<void> close() async => channel.sink.close();
}
